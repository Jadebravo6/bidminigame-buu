# Cub n Pup - puzzle game demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/desandro/pen/ezNawy](https://codepen.io/desandro/pen/ezNawy).

How to play: Drag cub to star, Drag grid to rotate.

Also available at [cubnpup.com](http://cubnpup.com)

This is a proof-of-concept for a game. Basic art, no sound, no options, no polish. But the core game-play is there. It's more of a mobile game, focused on dragging — inspired by Threes. I'm looking to see if its any fun. Let me know!

I've always wanted to make a video game. This could be the one. My previous attempts never got past isolated demos because they were aiming for bigger ideas. They grew complex and unwieldy. So this game is designed to be simple. A game that I can actually make.

