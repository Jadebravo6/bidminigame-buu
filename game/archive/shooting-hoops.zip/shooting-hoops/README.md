# Shooting Hoops

A Pen created on CodePen.io. Original URL: [https://codepen.io/dipscom/pen/amxYvB](https://codepen.io/dipscom/pen/amxYvB).

"Show me your magic, Johnson".

Works with mouse and touch input. Click/Touch and drag before flicking the ball towards the basket.