# Puzzle Game  | p5js

A Pen created on CodePen.io. Original URL: [https://codepen.io/DonKarlssonSan/pen/vgKoyE](https://codepen.io/DonKarlssonSan/pen/vgKoyE).

Remix/improvement challenge: fork the pen and make it possible to use any image. Either you upload it from your computer or you supply a URL. =) 

Any takers?!