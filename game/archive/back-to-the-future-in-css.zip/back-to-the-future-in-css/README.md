# Back to the Future in CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshbader/pen/yYpGwo](https://codepen.io/joshbader/pen/yYpGwo).

A short game based on the Movie Back to the Future in honour of Back to the Future Day (October 21st, 2015).